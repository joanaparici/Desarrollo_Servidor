package com.fpmislata.movies.http_response;

import lombok.Getter;
import lombok.Setter;

import java.util.Optional;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import jakarta.servlet.http.HttpServletRequest;

@Getter
@Setter
/**
 * La anotación @JsonPropertyOrder se utiliza para definir el orden en el que
 * las propiedades de un objeto
 * deben ser serializadas a JSON. En este caso, se está especificando que el
 * orden de serialización debe ser:
 * 1. total records
 * 2. totalPages
 * 3. page
 * 4. pageSize
 * 5. previous
 * 6. next
 * 7. data
 * 
 * Al serializar un objeto con estas propiedades usando Jackson, las propiedades
 * se presentarán en el JSON resultante
 * en el orden especificado anteriormente.
 */
@JsonPropertyOrder({ "total records", "total page", "page", "page size", "previous", "next", "data" })
@JsonInclude(JsonInclude.Include.NON_NULL)

public class Response {

    // Atributos de la respuesta

    private Object data; // Datos del listado (por ejemplo, películas, directores, etc.)
    @JsonProperty("total records")
    private Integer totalRecords; // Número total de registros en el listado
    private Integer page; // Número de la página actual
    @JsonProperty("page size")
    private Integer pageSize; // Tamaño de página (número de registros por página)
    @JsonProperty("total page")
    private Integer totalPages; // Número total de páginas en el listado
    private String next; // URL del siguiente conjunto de registros (si existe)
    private String previous; // URL del conjunto de registros anterior (si existe)

    // Constructor de la clase Response
    public Response(Object data, int totalRecords, Optional<Integer> page, int pageSize) {
        this.data = data;
        this.totalRecords = totalRecords;

        // Verificar si se proporcionó el número de página
        if (page.isPresent())
            buildPaginationMetaData(totalRecords, pageSize, page.get());
    }

    // Método para construir metadatos de paginación
    private void buildPaginationMetaData(int totalRecords, int pageSize, int page) {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String url = request.getRequestURL().toString();
        this.page = page;
        this.pageSize = pageSize;
        int totalPages = (int) (Math.ceil((double) totalRecords / pageSize));
        this.totalPages = totalPages;

        if(page > 1 && totalPages > 1)
            this.previous = url + "?page=" + (page - 1);
        if(page < totalPages)
            this.next = url + "?page=" + (page + 1);
    }
}
