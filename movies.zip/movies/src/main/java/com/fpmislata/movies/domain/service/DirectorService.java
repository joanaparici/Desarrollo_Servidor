package com.fpmislata.movies.domain.service;

import com.fpmislata.movies.domain.entity.Director;

public interface DirectorService {

    public void create(Director director);
}
