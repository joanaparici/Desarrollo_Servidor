package com.fpmislata.movies.controller;

import com.fpmislata.movies.domain.entity.Movie;
import com.fpmislata.movies.domain.service.MovieService;
import com.fpmislata.movies.http_response.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RequestMapping("/movies")
@RestController
public class MovieController {

    @Autowired
    private MovieService movieService;
    private final int LIMIT = 10;

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("")
    public Response getAll(@RequestParam Optional<Integer> page, @RequestParam Optional<Integer> pageSize) {
        // Obtener el número total de registros de películas
        int totalRecords = movieService.getTotalNumberOfRecords();
        
        // Determinar el tamaño de página utilizando pageSize si está presente, de lo contrario, utilizar el valor predeterminado (LIMIT)
        int limit = pageSize.isPresent() ? pageSize.get() : LIMIT;
        
        // Crear una instancia de Response para construir la respuesta
        Response response = new Response(movieService.getAll(page), totalRecords, page, limit);
        
        // Devolver la respuesta al cliente
        return response;
    }

    // @ResponseStatus(HttpStatus.OK)
    // @GetMapping("")
    // public Map<String, Object> getAll() {
    // Map<String, Object> response = new HashMap<>();
    // response.put("data", movieService.getAll());
    // int totalRecords = movieService.getTotalNumberOfRecords();
    // response.put("total records", totalRecords);
    // return response;
    // }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/{id}")
    public Movie find(@PathVariable("id") int id) {
        return movieService.find(id);

    }

}
