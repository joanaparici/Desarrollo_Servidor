package com.fpmislata.movies.persistence;

import com.fpmislata.movies.domain.entity.Director;

public interface DirectorRepository {
    void insert(Director director);
}