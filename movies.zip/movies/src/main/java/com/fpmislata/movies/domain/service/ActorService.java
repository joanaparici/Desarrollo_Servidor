package com.fpmislata.movies.domain.service;

import com.fpmislata.movies.domain.entity.Actor;

public interface ActorService {

    public void create(Actor actor);
}
