package com.fpmislata.movies.persistence;

import com.fpmislata.movies.domain.entity.Actor;

public interface ActorRepository {

    public void insert(Actor actor);
}
